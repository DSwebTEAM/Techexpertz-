import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { SearchBar } from '../ui/SearchBar';
import { Button } from '../ui/Button';
import { useTheme } from '../../context/ThemeContext';
import { useAuthStore } from '../../store/authStore';
import { Cpu, Menu, X, Moon, Sun, User, LogOut, LayoutDashboard, Settings, PenSquare } from 'lucide-react';

export const Header: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const { isAuthenticated, user, logout } = useAuthStore();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  const handleSearch = (term: string) => {
    console.log('Search term:', term);
    // In a real app, this would navigate to search results
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'py-3 bg-white/80 dark:bg-zinc-900/80 backdrop-blur-md shadow-md'
          : 'py-5 bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2">
          <motion.div
            initial={{ rotate: 0 }}
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear", repeatDelay: 5 }}
            className="bg-gradient-to-br from-primary-500 to-accent-500 text-white p-1.5 rounded-lg"
          >
            <Cpu size={20} />
          </motion.div>
          <motion.span
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="font-display text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary-600 to-accent-600 dark:from-primary-400 dark:to-accent-400"
          >
            TechExpertz
          </motion.span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-6">
          <SearchBar onSearch={handleSearch} className="w-64" />
          
          <nav className="flex items-center gap-5">
            <NavLink to="/" label="Home" />
            <NavLink to="/blog" label="Blog" />
            <NavLink to="/categories" label="Categories" />
            <NavLink to="/about" label="About" />
          </nav>
        </div>

        {/* Right side actions */}
        <div className="flex items-center gap-3">
          {/* Theme Toggle */}
          <motion.button
            whileTap={{ scale: 0.9 }}
            className="p-2 rounded-full glass text-zinc-700 dark:text-zinc-300 hover:shadow-neon dark:hover:shadow-neon"
            onClick={toggleTheme}
            aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
          >
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </motion.button>

          {/* Auth Buttons or User Menu */}
          <div className="hidden md:block">
            {isAuthenticated ? (
              <div className="relative">
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  className="flex items-center gap-2 glass p-1.5 pr-3 rounded-full"
                  onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                >
                  <img
                    src={user?.avatarUrl || 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150'}
                    alt={user?.username || 'User'}
                    className="w-7 h-7 rounded-full object-cover"
                  />
                  <span className="text-sm font-medium">{user?.username}</span>
                </motion.button>

                {/* User Dropdown Menu */}
                <AnimatePresence>
                  {isProfileMenuOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className="absolute right-0 mt-2 w-48 glass rounded-xl shadow-lg py-1 z-10"
                    >
                      <div className="px-4 py-2 border-b border-zinc-200 dark:border-zinc-700">
                        <p className="text-sm font-semibold">{user?.name}</p>
                        <p className="text-xs text-zinc-500 dark:text-zinc-400">{user?.email}</p>
                      </div>
                      
                      <ul>
                        <UserMenuItem to="/dashboard" icon={<LayoutDashboard size={16} />} label="Dashboard" />
                        <UserMenuItem to="/new-post" icon={<PenSquare size={16} />} label="New Post" />
                        <UserMenuItem to="/profile" icon={<User size={16} />} label="Profile" />
                        <UserMenuItem to="/settings" icon={<Settings size={16} />} label="Settings" />
                        <li className="border-t border-zinc-200 dark:border-zinc-700 mt-1">
                          <button
                            className="flex w-full items-center gap-2 px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-zinc-100 dark:hover:bg-zinc-800"
                            onClick={() => {
                              logout();
                              setIsProfileMenuOpen(false);
                            }}
                          >
                            <LogOut size={16} />
                            <span>Log out</span>
                          </button>
                        </li>
                      </ul>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Link to="/login">
                  <Button variant="ghost" size="sm">
                    Log In
                  </Button>
                </Link>
                <Link to="/register">
                  <Button variant="primary" size="sm">
                    Sign Up
                  </Button>
                </Link>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 rounded-md"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden glass overflow-hidden"
          >
            <div className="container mx-auto px-4 py-4 flex flex-col gap-4">
              <SearchBar onSearch={handleSearch} />
              
              <nav className="flex flex-col gap-3">
                <MobileNavLink to="/" label="Home" />
                <MobileNavLink to="/blog" label="Blog" />
                <MobileNavLink to="/categories" label="Categories" />
                <MobileNavLink to="/about" label="About" />
              </nav>
              
              {isAuthenticated ? (
                <div className="flex flex-col gap-3 border-t border-zinc-200 dark:border-zinc-700 pt-3">
                  <MobileNavLink to="/dashboard" label="Dashboard" />
                  <MobileNavLink to="/new-post" label="New Post" />
                  <MobileNavLink to="/profile" label="Profile" />
                  <button
                    className="flex items-center gap-2 p-2 text-red-600 dark:text-red-400"
                    onClick={logout}
                  >
                    <LogOut size={18} />
                    <span>Log out</span>
                  </button>
                </div>
              ) : (
                <div className="flex flex-col gap-3 border-t border-zinc-200 dark:border-zinc-700 pt-3">
                  <Link to="/login" className="w-full">
                    <Button variant="ghost" fullWidth>
                      Log In
                    </Button>
                  </Link>
                  <Link to="/register" className="w-full">
                    <Button variant="primary" fullWidth>
                      Sign Up
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

// Helper Components

interface NavLinkProps {
  to: string;
  label: string;
}

const NavLink: React.FC<NavLinkProps> = ({ to, label }) => {
  const location = useLocation();
  const isActive = location.pathname === to || 
    (to !== '/' && location.pathname.startsWith(to));

  return (
    <Link
      to={to}
      className={`relative px-1 py-2 text-sm font-medium transition-colors ${
        isActive 
          ? 'text-primary-600 dark:text-primary-400' 
          : 'text-zinc-700 dark:text-zinc-300 hover:text-primary-600 dark:hover:text-primary-400'
      }`}
    >
      {label}
      {isActive && (
        <motion.div
          layoutId="nav-underline"
          className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-primary-500 to-accent-500"
          initial={false}
        />
      )}
    </Link>
  );
};

const MobileNavLink: React.FC<NavLinkProps> = ({ to, label }) => {
  const location = useLocation();
  const isActive = location.pathname === to || 
    (to !== '/' && location.pathname.startsWith(to));

  return (
    <Link
      to={to}
      className={`p-2 rounded-md ${
        isActive 
          ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400' 
          : 'text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800'
      }`}
    >
      {label}
    </Link>
  );
};

interface UserMenuItemProps {
  to: string;
  icon: React.ReactNode;
  label: string;
}

const UserMenuItem: React.FC<UserMenuItemProps> = ({ to, icon, label }) => (
  <li>
    <Link
      to={to}
      className="flex items-center gap-2 px-4 py-2 text-sm hover:bg-zinc-100 dark:hover:bg-zinc-800"
    >
      {icon}
      <span>{label}</span>
    </Link>
  </li>
);