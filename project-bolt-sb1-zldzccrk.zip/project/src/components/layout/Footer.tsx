import React from 'react';
import { Link } from 'react-router-dom';
import { Github, Twitter, Facebook, Instagram, Cpu, ArrowRight } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-zinc-100 dark:bg-zinc-900 pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Column */}
          <div className="md:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="bg-gradient-to-br from-primary-500 to-accent-500 text-white p-2 rounded-lg">
                <Cpu size={24} />
              </div>
              <span className="font-display text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary-600 to-accent-600 dark:from-primary-400 dark:to-accent-400">
                TechExpertz
              </span>
            </Link>
            <p className="text-zinc-600 dark:text-zinc-400 text-sm mb-4">
              Explore the cutting edge of technology with insights, reviews, and expert analysis on the latest tech trends.
            </p>
            <div className="flex gap-4">
              <SocialLink href="#" icon={<Twitter size={18} />} label="Twitter" />
              <SocialLink href="#" icon={<Facebook size={18} />} label="Facebook" />
              <SocialLink href="#" icon={<Instagram size={18} />} label="Instagram" />
              <SocialLink href="#" icon={<Github size={18} />} label="GitHub" />
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-zinc-900 dark:text-white font-semibold text-lg mb-4">
              Quick Links
            </h3>
            <ul className="space-y-2">
              <FooterLink to="/" label="Home" />
              <FooterLink to="/blog" label="Blog" />
              <FooterLink to="/categories" label="Categories" />
              <FooterLink to="/about" label="About Us" />
              <FooterLink to="/contact" label="Contact" />
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h3 className="text-zinc-900 dark:text-white font-semibold text-lg mb-4">
              Categories
            </h3>
            <ul className="space-y-2">
              <FooterLink to="/blog/category/ai-ml" label="AI & Machine Learning" />
              <FooterLink to="/blog/category/gadgets" label="Gadgets" />
              <FooterLink to="/blog/category/blockchain" label="Blockchain" />
              <FooterLink to="/blog/category/cybersecurity" label="Cybersecurity" />
              <FooterLink to="/blog/category/future-tech" label="Future Tech" />
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="text-zinc-900 dark:text-white font-semibold text-lg mb-4">
              Stay Updated
            </h3>
            <p className="text-zinc-600 dark:text-zinc-400 text-sm mb-4">
              Subscribe to our newsletter for weekly tech insights.
            </p>
            <form className="flex">
              <input
                type="email"
                placeholder="Your email"
                className="input text-sm py-2"
                required
              />
              <button
                type="submit"
                className="btn-primary ml-2 px-3"
                aria-label="Subscribe"
              >
                <ArrowRight size={18} />
              </button>
            </form>
          </div>
        </div>

        <div className="border-t border-zinc-200 dark:border-zinc-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-zinc-500 dark:text-zinc-400 text-sm">
            © {new Date().getFullYear()} TechExpertz. All rights reserved.
          </p>
          <div className="flex gap-6 mt-4 md:mt-0">
            <a href="#" className="text-zinc-500 hover:text-zinc-700 dark:text-zinc-400 dark:hover:text-zinc-300 text-sm">
              Privacy Policy
            </a>
            <a href="#" className="text-zinc-500 hover:text-zinc-700 dark:text-zinc-400 dark:hover:text-zinc-300 text-sm">
              Terms of Service
            </a>
            <a href="#" className="text-zinc-500 hover:text-zinc-700 dark:text-zinc-400 dark:hover:text-zinc-300 text-sm">
              Cookie Policy
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

interface FooterLinkProps {
  to: string;
  label: string;
}

const FooterLink: React.FC<FooterLinkProps> = ({ to, label }) => (
  <li>
    <Link 
      to={to} 
      className="text-zinc-600 hover:text-primary-600 dark:text-zinc-400 dark:hover:text-primary-400 text-sm transition-colors"
    >
      {label}
    </Link>
  </li>
);

interface SocialLinkProps {
  href: string;
  icon: React.ReactNode;
  label: string;
}

const SocialLink: React.FC<SocialLinkProps> = ({ href, icon, label }) => (
  <a 
    href={href} 
    aria-label={label}
    className="bg-white dark:bg-zinc-800 p-2 rounded-full text-zinc-700 dark:text-zinc-300 hover:text-primary-600 dark:hover:text-primary-400 shadow-sm hover:shadow transition-all"
  >
    {icon}
  </a>
);