import React, { useState } from 'react';
import { Search, X } from 'lucide-react';
import { motion } from 'framer-motion';

interface SearchBarProps {
  onSearch: (term: string) => void;
  placeholder?: string;
  className?: string;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  onSearch,
  placeholder = 'Search for articles, topics...',
  className = '',
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isFocused, setIsFocused] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      onSearch(searchTerm.trim());
    }
  };

  const clearSearch = () => {
    setSearchTerm('');
    onSearch('');
  };

  return (
    <motion.form
      initial={{ opacity: 0.9 }}
      animate={{ 
        opacity: 1,
        boxShadow: isFocused ? '0 0 0 2px rgba(139, 92, 246, 0.5)' : 'none'
      }}
      className={`glass relative rounded-full overflow-hidden flex items-center ${className}`}
      onSubmit={handleSearch}
    >
      <Search 
        size={18} 
        className="absolute left-4 text-zinc-400 dark:text-zinc-500" 
      />
      
      <input
        type="text"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-transparent pl-10 pr-10 py-2 text-sm focus:outline-none"
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
      />
      
      {searchTerm && (
        <button
          type="button"
          onClick={clearSearch}
          className="absolute right-10 text-zinc-400 hover:text-zinc-600 dark:text-zinc-500 dark:hover:text-zinc-300 transition-colors"
        >
          <X size={16} />
        </button>
      )}
      
      <button
        type="submit"
        className="absolute right-2 text-zinc-500 hover:text-primary-500 dark:text-zinc-400 dark:hover:text-primary-400 p-1 rounded-full transition-colors"
        aria-label="Search"
      >
        <motion.div
          whileTap={{ scale: 0.9 }}
        >
          <Search size={18} />
        </motion.div>
      </button>
    </motion.form>
  );
};