import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Badge } from '../ui/Badge';
import { Post } from '../../types';
import { Clock, Eye, Heart } from 'lucide-react';
import { format } from 'date-fns';

interface PostCardProps {
  post: Post;
  featured?: boolean;
}

export const PostCard: React.FC<PostCardProps> = ({ post, featured = false }) => {
  const {
    id,
    title,
    slug,
    excerpt,
    coverImage,
    author,
    category,
    tags,
    publishedAt,
    readingTime,
    views,
    likes,
  } = post;

  const formattedDate = publishedAt 
    ? format(new Date(publishedAt), 'MMM d, yyyy')
    : '';

  if (featured) {
    return (
      <motion.article
        className="glass-card overflow-hidden col-span-12 lg:col-span-6 relative card-hover"
        whileHover={{ y: -5 }}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="grid grid-cols-1 md:grid-cols-2 h-full">
          <div className="relative h-60 md:h-full overflow-hidden">
            <div className="absolute top-4 left-4 z-10">
              <Badge
                variant="primary"
                className="font-bold uppercase text-xs tracking-wider"
              >
                Featured
              </Badge>
            </div>
            <img
              src={coverImage || 'https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'}
              alt={title}
              className="w-full h-full object-cover transform transition-transform duration-500 hover:scale-110"
            />
          </div>
          
          <div className="p-6 flex flex-col">
            <Link to={`/blog/category/${category.slug}`}>
              <Badge
                variant={getBadgeVariant(category.name)}
                className="mb-3"
              >
                {category.name}
              </Badge>
            </Link>
            
            <Link to={`/blog/${slug}`} className="group">
              <h3 className="text-xl font-bold mb-3 group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors">
                {title}
              </h3>
            </Link>
            
            <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-4 line-clamp-3">
              {excerpt}
            </p>
            
            <div className="flex items-center gap-2 mt-auto">
              <img
                src={author.avatarUrl || 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150'}
                alt={author.name}
                className="w-8 h-8 rounded-full object-cover"
              />
              <div>
                <p className="text-xs font-medium">{author.name}</p>
                <div className="flex items-center gap-3 text-xs text-zinc-500 dark:text-zinc-400">
                  <span>{formattedDate}</span>
                  <span className="flex items-center">
                    <Clock size={12} className="mr-1" />
                    {readingTime} min
                  </span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-4 mt-4 text-xs text-zinc-500 dark:text-zinc-400">
              <span className="flex items-center gap-1">
                <Eye size={14} />
                {views}
              </span>
              <span className="flex items-center gap-1">
                <Heart size={14} />
                {likes}
              </span>
            </div>
          </div>
        </div>
      </motion.article>
    );
  }

  return (
    <motion.article
      className="glass-card overflow-hidden card-hover h-full"
      whileHover={{ y: -5 }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="relative h-48 overflow-hidden">
        <img
          src={coverImage || 'https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'}
          alt={title}
          className="w-full h-full object-cover transform transition-transform duration-500 hover:scale-110"
        />
      </div>
      
      <div className="p-5">
        <Link to={`/blog/category/${category.slug}`}>
          <Badge
            variant={getBadgeVariant(category.name)}
            className="mb-3"
          >
            {category.name}
          </Badge>
        </Link>
        
        <Link to={`/blog/${slug}`} className="group">
          <h3 className="text-lg font-bold mb-2 line-clamp-2 group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors">
            {title}
          </h3>
        </Link>
        
        <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-4 line-clamp-2">
          {excerpt}
        </p>
        
        <div className="flex items-center justify-between mt-4">
          <div className="flex items-center gap-2">
            <img
              src={author.avatarUrl || 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150'}
              alt={author.name}
              className="w-6 h-6 rounded-full object-cover"
            />
            <span className="text-xs font-medium">{author.name}</span>
          </div>
          
          <div className="flex items-center gap-3 text-xs text-zinc-500 dark:text-zinc-400">
            <span className="flex items-center">
              <Clock size={12} className="mr-1" />
              {readingTime} min
            </span>
          </div>
        </div>
      </div>
    </motion.article>
  );
};

// Helper function to map category names to badge variants
const getBadgeVariant = (categoryName: string): 'primary' | 'secondary' | 'accent' | 'success' | 'warning' | 'error' => {
  const categoryMap: Record<string, 'primary' | 'secondary' | 'accent' | 'success' | 'warning' | 'error'> = {
    'AI & Machine Learning': 'primary',
    'Gadgets': 'secondary',
    'Blockchain': 'accent',
    'Cybersecurity': 'warning',
    'Future Tech': 'success',
    // Add more mappings as needed
  };

  return categoryMap[categoryName] || 'primary';
};