import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Category } from '../../types';

interface CategoryListProps {
  categories: Category[];
  className?: string;
}

export const CategoryList: React.FC<CategoryListProps> = ({ categories, className = '' }) => {
  return (
    <section className={`${className}`}>
      <h2 className="text-xl font-bold mb-4">Categories</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {categories.map((category) => (
          <CategoryItem key={category.id} category={category} />
        ))}
      </div>
    </section>
  );
};

interface CategoryItemProps {
  category: Category;
}

export const CategoryItem: React.FC<CategoryItemProps> = ({ category }) => {
  const getCategoryColor = (colorName?: string) => {
    const colorMap: Record<string, string> = {
      'primary': 'from-primary-500 to-primary-700',
      'secondary': 'from-secondary-500 to-secondary-700',
      'accent': 'from-accent-500 to-accent-700',
      'success': 'from-success-500 to-success-700',
      'warning': 'from-warning-500 to-warning-700',
      'error': 'from-error-500 to-error-700',
    };

    return colorMap[colorName || 'primary'] || 'from-primary-500 to-primary-700';
  };

  return (
    <motion.div whileHover={{ y: -3 }} whileTap={{ scale: 0.98 }}>
      <Link 
        to={`/blog/category/${category.slug}`}
        className="glass-card group p-4 block hover:shadow-neon"
      >
        <div className="flex justify-between items-center">
          <div>
            <h3 className="font-medium text-md group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors">
              {category.name}
            </h3>
            {category.description && (
              <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1 line-clamp-1">
                {category.description}
              </p>
            )}
          </div>
          
          <div className={`bg-gradient-to-r ${getCategoryColor(category.color)} text-white rounded-full px-2 py-1 text-xs font-medium`}>
            {category.postCount} posts
          </div>
        </div>
      </Link>
    </motion.div>
  );
};