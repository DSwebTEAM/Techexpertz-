import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Tag } from '../../types';

interface TagCloudProps {
  tags: Tag[];
  className?: string;
}

export const TagCloud: React.FC<TagCloudProps> = ({ tags, className = '' }) => {
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 10 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <section className={`${className}`}>
      <h2 className="text-xl font-bold mb-4">Popular Tags</h2>
      <motion.div 
        className="flex flex-wrap gap-2"
        variants={container}
        initial="hidden"
        animate="show"
      >
        {tags.map((tag) => (
          <TagItem key={tag.id} tag={tag} variants={item} />
        ))}
      </motion.div>
    </section>
  );
};

interface TagItemProps {
  tag: Tag;
  variants?: any;
}

const getTagColorClasses = (color?: string) => {
  const colorMap: Record<string, string> = {
    'primary': 'bg-primary-50 text-primary-700 dark:bg-primary-900/20 dark:text-primary-300 hover:bg-primary-100 dark:hover:bg-primary-800/30',
    'secondary': 'bg-secondary-50 text-secondary-700 dark:bg-secondary-900/20 dark:text-secondary-300 hover:bg-secondary-100 dark:hover:bg-secondary-800/30',
    'accent': 'bg-accent-50 text-accent-700 dark:bg-accent-900/20 dark:text-accent-300 hover:bg-accent-100 dark:hover:bg-accent-800/30',
    'success': 'bg-success-50 text-success-700 dark:bg-success-900/20 dark:text-success-300 hover:bg-success-100 dark:hover:bg-success-800/30',
    'warning': 'bg-warning-50 text-warning-700 dark:bg-warning-900/20 dark:text-warning-300 hover:bg-warning-100 dark:hover:bg-warning-800/30',
    'error': 'bg-error-50 text-error-700 dark:bg-error-900/20 dark:text-error-300 hover:bg-error-100 dark:hover:bg-error-800/30',
  };

  return colorMap[color || 'primary'] || 'bg-primary-50 text-primary-700 dark:bg-primary-900/20 dark:text-primary-300 hover:bg-primary-100 dark:hover:bg-primary-800/30';
};

const TagItem: React.FC<TagItemProps> = ({ tag, variants }) => (
  <motion.div variants={variants}>
    <Link 
      to={`/blog/tag/${tag.slug}`}
      className={`px-3 py-1 rounded-full text-sm ${getTagColorClasses(tag.color)} transition-colors`}
    >
      {tag.name}
      {tag.postCount && <span className="ml-1 text-xs opacity-70">({tag.postCount})</span>}
    </Link>
  </motion.div>
);