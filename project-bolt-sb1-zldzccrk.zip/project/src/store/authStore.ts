import { create } from 'zustand';
import { AuthState, User } from '../types';

// Mock user data - in a real app, this would come from your API
const MOCK_USER: User = {
  id: '1',
  username: 'techguru',
  email: 'guru@techexpertz.com',
  name: 'Tech Guru',
  bio: 'Passionate about cutting-edge technology and futuristic innovations.',
  avatarUrl: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150',
  role: 'author',
  createdAt: new Date().toISOString(),
};

interface AuthStore extends AuthState {
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, username: string, password: string) => Promise<void>;
  logout: () => void;
  updateUser: (userData: Partial<User>) => Promise<void>;
}

export const useAuthStore = create<AuthStore>((set) => ({
  user: null,
  isAuthenticated: false,
  isLoading: false,
  error: null,

  login: async (email, password) => {
    set({ isLoading: true, error: null });
    
    // Simulate API call
    try {
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // In a real app, validate credentials from your API
      if (email === 'guru@techexpertz.com' && password === 'password') {
        set({
          user: MOCK_USER,
          isAuthenticated: true,
          isLoading: false,
        });
      } else {
        set({
          error: 'Invalid email or password',
          isLoading: false,
        });
      }
    } catch (error) {
      set({
        error: 'An error occurred during login',
        isLoading: false,
      });
    }
  },

  register: async (email, username, password) => {
    set({ isLoading: true, error: null });
    
    // Simulate API call
    try {
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // In a real app, this would send registration data to your API
      const newUser: User = {
        ...MOCK_USER,
        id: '2',
        email,
        username,
        name: username,
        role: 'user',
      };
      
      set({
        user: newUser,
        isAuthenticated: true,
        isLoading: false,
      });
    } catch (error) {
      set({
        error: 'An error occurred during registration',
        isLoading: false,
      });
    }
  },

  logout: () => {
    // In a real app, make a call to your API to invalidate the session/token
    set({
      user: null,
      isAuthenticated: false,
      error: null,
    });
  },

  updateUser: async (userData) => {
    set({ isLoading: true, error: null });
    
    // Simulate API call
    try {
      await new Promise(resolve => setTimeout(resolve, 800));
      
      set(state => ({
        user: state.user ? { ...state.user, ...userData } : null,
        isLoading: false,
      }));
    } catch (error) {
      set({
        error: 'An error occurred while updating profile',
        isLoading: false,
      });
    }
  },
}));