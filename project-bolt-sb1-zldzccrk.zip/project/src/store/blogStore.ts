import { create } from 'zustand';
import { Category, Comment, Post, Tag } from '../types';
import { format } from 'date-fns';

// Mock data for the blog
const MOCK_CATEGORIES: Category[] = [
  { id: '1', name: 'AI & Machine Learning', slug: 'ai-ml', description: 'Latest in artificial intelligence and machine learning', color: 'primary', postCount: 5 },
  { id: '2', name: 'Gadgets', slug: 'gadgets', description: 'Reviews and news about the latest tech gadgets', color: 'secondary', postCount: 3 },
  { id: '3', name: 'Blockchain', slug: 'blockchain', description: 'Exploring blockchain technology and cryptocurrencies', color: 'accent', postCount: 2 },
  { id: '4', name: 'Cybersecurity', slug: 'cybersecurity', description: 'Security news, threats, and protection strategies', color: 'warning', postCount: 2 },
  { id: '5', name: 'Future Tech', slug: 'future-tech', description: 'Emerging technologies and future predictions', color: 'success', postCount: 4 },
];

const MOCK_TAGS: Tag[] = [
  { id: '1', name: 'Artificial Intelligence', slug: 'ai', color: 'primary', postCount: 3 },
  { id: '2', name: 'Machine Learning', slug: 'ml', color: 'primary', postCount: 2 },
  { id: '3', name: 'VR/AR', slug: 'vr-ar', color: 'secondary', postCount: 2 },
  { id: '4', name: 'Smartphones', slug: 'smartphones', color: 'accent', postCount: 2 },
  { id: '5', name: 'Smart Home', slug: 'smart-home', color: 'success', postCount: 1 },
  { id: '6', name: 'Crypto', slug: 'crypto', color: 'warning', postCount: 1 },
  { id: '7', name: 'Privacy', slug: 'privacy', color: 'error', postCount: 1 },
  { id: '8', name: 'Quantum Computing', slug: 'quantum', color: 'primary', postCount: 1 },
];

// Helper function to create mock posts
const createMockPosts = (): Post[] => {
  const author = {
    id: '1',
    username: 'techguru',
    email: 'guru@techexpertz.com',
    name: 'Tech Guru',
    avatarUrl: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150',
    role: 'author',
    createdAt: new Date().toISOString(),
  };

  const posts: Post[] = [
    {
      id: '1',
      title: 'The Future of AI: How Machine Learning is Revolutionizing Industries',
      slug: 'future-of-ai-ml-revolutionizing-industries',
      excerpt: 'Discover how advanced AI systems are transforming business operations across sectors.',
      content: 
`# The Future of AI: How Machine Learning is Revolutionizing Industries

Artificial intelligence and machine learning technologies are rapidly transforming industries across the globe. From healthcare to finance, transportation to retail, AI applications are creating new efficiencies and opportunities.

## Key Innovations

- **Natural Language Processing**: Systems like GPT-4 can understand and generate human-like text
- **Computer Vision**: AI can now interpret and understand visual information at human-level accuracy
- **Reinforcement Learning**: AI systems that learn optimal behaviors through trial and error

## Industry Applications

### Healthcare

AI is revolutionizing patient care through more accurate diagnostics, personalized treatment plans, and drug discovery acceleration.

### Finance

Automated trading systems, fraud detection, and personalized banking experiences are all being enhanced by machine learning algorithms.

### Transportation

Self-driving vehicles and optimized logistics networks are becoming reality thanks to advancements in AI.

## Ethical Considerations

As AI becomes more powerful, important questions about privacy, bias, and accountability must be addressed by technologists and policymakers alike.`,
      coverImage: 'https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      featured: true,
      published: true,
      publishedAt: format(new Date(), 'yyyy-MM-dd\'T\'HH:mm:ss'),
      authorId: '1',
      author,
      categoryId: '1',
      category: MOCK_CATEGORIES[0],
      tags: [MOCK_TAGS[0], MOCK_TAGS[1]],
      createdAt: format(new Date(), 'yyyy-MM-dd\'T\'HH:mm:ss'),
      updatedAt: format(new Date(), 'yyyy-MM-dd\'T\'HH:mm:ss'),
      readingTime: 5,
      views: 1250,
      likes: 78,
    },
    {
      id: '2',
      title: 'Quantum Computing: The Next Frontier in Technology',
      slug: 'quantum-computing-next-frontier',
      excerpt: 'Exploring the potential of quantum computing to solve previously impossible problems.',
      content:
`# Quantum Computing: The Next Frontier in Technology

Quantum computing represents a fundamental shift in how we process information, leveraging quantum mechanical phenomena to perform calculations.

## Quantum Principles

- **Superposition**: Quantum bits (qubits) can exist in multiple states simultaneously
- **Entanglement**: Qubits can be correlated in ways that have no classical equivalent
- **Quantum Tunneling**: Particles can pass through energy barriers impossible in classical physics

## Recent Breakthroughs

Several major technology companies have achieved quantum supremacy, demonstrating that quantum computers can solve specific problems faster than classical computers.

## Potential Applications

- **Drug Discovery**: Quantum computers could simulate molecular interactions at unprecedented scales
- **Materials Science**: Discover new materials with precisely engineered properties
- **Cryptography**: Both breaking existing encryption and creating quantum-secure alternatives
- **Optimization Problems**: Solving complex logistics and routing challenges

## Challenges Ahead

Despite the promising advances, quantum computers still face significant challenges in error correction, qubit stability, and scaling to practical applications.`,
      coverImage: 'https://images.pexels.com/photos/373543/pexels-photo-373543.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      featured: true,
      published: true,
      publishedAt: format(new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd\'T\'HH:mm:ss'),
      authorId: '1',
      author,
      categoryId: '5',
      category: MOCK_CATEGORIES[4],
      tags: [MOCK_TAGS[7]],
      createdAt: format(new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd\'T\'HH:mm:ss'),
      updatedAt: format(new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd\'T\'HH:mm:ss'),
      readingTime: 6,
      views: 980,
      likes: 54,
    },
    {
      id: '3',
      title: 'The Evolution of VR: From Gaming to Enterprise Applications',
      slug: 'evolution-vr-gaming-enterprise',
      excerpt: 'How virtual reality has matured from entertainment to transforming business operations.',
      content: 'Full article content about VR evolution...',
      coverImage: 'https://images.pexels.com/photos/3183150/pexels-photo-3183150.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      featured: false,
      published: true,
      publishedAt: format(new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd\'T\'HH:mm:ss'),
      authorId: '1',
      author,
      categoryId: '2',
      category: MOCK_CATEGORIES[1],
      tags: [MOCK_TAGS[2]],
      createdAt: format(new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd\'T\'HH:mm:ss'),
      updatedAt: format(new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd\'T\'HH:mm:ss'),
      readingTime: 4,
      views: 755,
      likes: 32,
    },
    {
      id: '4',
      title: 'Blockchain Beyond Cryptocurrency: Enterprise Use Cases',
      slug: 'blockchain-beyond-crypto-enterprise-cases',
      excerpt: 'Exploring how distributed ledger technology is being adopted across industries.',
      content: 'Full article content about blockchain applications...',
      coverImage: 'https://images.pexels.com/photos/844124/pexels-photo-844124.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      featured: false,
      published: true,
      publishedAt: format(new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd\'T\'HH:mm:ss'),
      authorId: '1',
      author,
      categoryId: '3',
      category: MOCK_CATEGORIES[2],
      tags: [MOCK_TAGS[5]],
      createdAt: format(new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd\'T\'HH:mm:ss'),
      updatedAt: format(new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd\'T\'HH:mm:ss'),
      readingTime: 5,
      views: 623,
      likes: 41,
    },
    {
      id: '5',
      title: 'Cybersecurity in 2025: Preparing for Emerging Threats',
      slug: 'cybersecurity-2025-emerging-threats',
      excerpt: 'What organizations need to know about the evolving threat landscape.',
      content: 'Full article content about cybersecurity trends...',
      coverImage: 'https://images.pexels.com/photos/1089438/pexels-photo-1089438.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      featured: false,
      published: true,
      publishedAt: format(new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd\'T\'HH:mm:ss'),
      authorId: '1',
      author,
      categoryId: '4',
      category: MOCK_CATEGORIES[3],
      tags: [MOCK_TAGS[6]],
      createdAt: format(new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd\'T\'HH:mm:ss'),
      updatedAt: format(new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd\'T\'HH:mm:ss'),
      readingTime: 7,
      views: 892,
      likes: 63,
    },
    {
      id: '6',
      title: 'Smart Home Technology in 2025: What to Expect',
      slug: 'smart-home-technology-2025',
      excerpt: "The future of connected homes and how they'll integrate with our daily lives.",
      content: 'Full article content about smart home trends...',
      coverImage: 'https://images.pexels.com/photos/1350197/pexels-photo-1350197.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      featured: false,
      published: true,
      publishedAt: format(new Date(Date.now() - 12 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd\'T\'HH:mm:ss'),
      authorId: '1',
      author,
      categoryId: '5',
      category: MOCK_CATEGORIES[4],
      tags: [MOCK_TAGS[4]],
      createdAt: format(new Date(Date.now() - 12 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd\'T\'HH:mm:ss'),
      updatedAt: format(new Date(Date.now() - 12 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd\'T\'HH:mm:ss'),
      readingTime: 4,
      views: 712,
      likes: 45,
    },
  ];

  return posts;
};

interface BlogState {
  posts: Post[];
  categories: Category[];
  tags: Tag[];
  comments: Comment[];
  isLoading: boolean;
  error: string | null;
}

interface BlogStore extends BlogState {
  fetchPosts: () => Promise<void>;
  fetchPostById: (id: string) => Promise<Post | undefined>;
  fetchPostBySlug: (slug: string) => Promise<Post | undefined>;
  fetchCategories: () => Promise<void>;
  fetchTags: () => Promise<void>;
  createPost: (post: Omit<Post, 'id' | 'createdAt' | 'updatedAt' | 'views' | 'likes'>) => Promise<Post>;
  updatePost: (id: string, postData: Partial<Post>) => Promise<Post>;
  deletePost: (id: string) => Promise<void>;
  likePost: (id: string) => Promise<void>;
}

export const useBlogStore = create<BlogStore>((set, get) => ({
  posts: [],
  categories: [],
  tags: [],
  comments: [],
  isLoading: false,
  error: null,

  fetchPosts: async () => {
    set({ isLoading: true, error: null });
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 800));
      
      const posts = createMockPosts();
      set({ posts, isLoading: false });
    } catch (error) {
      set({
        error: 'Failed to fetch posts',
        isLoading: false,
      });
    }
  },

  fetchPostById: async (id) => {
    set({ isLoading: true, error: null });
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const post = get().posts.find(p => p.id === id);
      set({ isLoading: false });
      return post;
    } catch (error) {
      set({
        error: 'Failed to fetch post',
        isLoading: false,
      });
    }
  },

  fetchPostBySlug: async (slug) => {
    set({ isLoading: true, error: null });
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const post = get().posts.find(p => p.slug === slug);
      set({ isLoading: false });
      return post;
    } catch (error) {
      set({
        error: 'Failed to fetch post',
        isLoading: false,
      });
    }
  },

  fetchCategories: async () => {
    set({ isLoading: true, error: null });
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      set({ categories: MOCK_CATEGORIES, isLoading: false });
    } catch (error) {
      set({
        error: 'Failed to fetch categories',
        isLoading: false,
      });
    }
  },

  fetchTags: async () => {
    set({ isLoading: true, error: null });
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      set({ tags: MOCK_TAGS, isLoading: false });
    } catch (error) {
      set({
        error: 'Failed to fetch tags',
        isLoading: false,
      });
    }
  },

  createPost: async (postData) => {
    set({ isLoading: true, error: null });
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const newPost: Post = {
        ...postData,
        id: Math.random().toString(36).substring(2, 11),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        views: 0,
        likes: 0,
      };
      
      set(state => ({
        posts: [...state.posts, newPost],
        isLoading: false,
      }));
      
      return newPost;
    } catch (error) {
      set({
        error: 'Failed to create post',
        isLoading: false,
      });
      throw error;
    }
  },

  updatePost: async (id, postData) => {
    set({ isLoading: true, error: null });
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      let updatedPost: Post | undefined;
      
      set(state => {
        const posts = state.posts.map(post => {
          if (post.id === id) {
            updatedPost = {
              ...post,
              ...postData,
              updatedAt: new Date().toISOString(),
            };
            return updatedPost;
          }
          return post;
        });
        
        return { posts, isLoading: false };
      });
      
      if (!updatedPost) {
        throw new Error('Post not found');
      }
      
      return updatedPost;
    } catch (error) {
      set({
        error: 'Failed to update post',
        isLoading: false,
      });
      throw error;
    }
  },

  deletePost: async (id) => {
    set({ isLoading: true, error: null });
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 800));
      
      set(state => ({
        posts: state.posts.filter(post => post.id !== id),
        isLoading: false,
      }));
    } catch (error) {
      set({
        error: 'Failed to delete post',
        isLoading: false,
      });
    }
  },

  likePost: async (id) => {
    try {
      set(state => ({
        posts: state.posts.map(post => {
          if (post.id === id) {
            return { ...post, likes: post.likes + 1 };
          }
          return post;
        }),
      }));
    } catch (error) {
      set({
        error: 'Failed to like post',
      });
    }
  },
}));