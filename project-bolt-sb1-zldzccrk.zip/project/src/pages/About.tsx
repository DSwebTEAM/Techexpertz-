import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Cpu, Users, Award, Star, GraduationCap, Rss } from 'lucide-react';

const AboutPage: React.FC = () => {
  return (
    <div className="pt-10 pb-20">
      {/* Hero Section */}
      <section className="py-16 md:py-24 px-4 bg-gradient-to-br from-indigo-100 to-violet-100 dark:from-zinc-900 dark:to-zinc-800">
        <div className="container mx-auto text-center">
          <motion.h1 
            className="text-3xl md:text-5xl font-bold mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            About <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary-600 to-accent-600 dark:from-primary-400 dark:to-accent-400">TechExpertz</span>
          </motion.h1>
          
          <motion.p 
            className="text-lg md:text-xl text-zinc-700 dark:text-zinc-300 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            Your trusted source for cutting-edge tech news, reviews, and insightful analysis since 2025.
          </motion.p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="section py-16">
        <div className="glass-card p-8 md:p-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold mb-6">Our Mission</h2>
              <p className="text-zinc-700 dark:text-zinc-300 mb-4">
                At TechExpertz, we believe technology should be accessible and understandable to everyone. Our mission is to demystify complex technological concepts and deliver clear, insightful analysis on the innovations shaping our digital future.
              </p>
              <p className="text-zinc-700 dark:text-zinc-300 mb-4">
                We're committed to providing honest, unbiased perspectives on the latest advancements, equipping our readers with the knowledge they need to navigate the rapidly evolving tech landscape.
              </p>
              <p className="text-zinc-700 dark:text-zinc-300">
                Whether you're a tech enthusiast, industry professional, or simply curious about the future of technology, TechExpertz is your trusted companion on this digital journey.
              </p>
            </div>
            
            <div className="relative">
              <div className="aspect-video rounded-xl overflow-hidden shadow-lg">
                <img 
                  src="https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                  alt="Tech team collaborating" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 bg-gradient-to-br from-primary-500 to-accent-500 text-white p-4 rounded-lg shadow-xl">
                <Cpu size={32} />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="section py-16">
        <h2 className="text-2xl md:text-3xl font-bold mb-10 text-center">Our Core Values</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <ValueCard 
            icon={<Star className="text-accent-500" size={24} />}
            title="Excellence"
            description="We strive for excellence in every article, review, and analysis we publish. Our content undergoes rigorous fact-checking and quality control."
          />
          
          <ValueCard 
            icon={<Award className="text-primary-500" size={24} />}
            title="Integrity"
            description="We maintain complete editorial independence and transparency. Our reviews are honest, and our analysis is unbiased and objective."
          />
          
          <ValueCard 
            icon={<Users className="text-secondary-500" size={24} />}
            title="Community"
            description="We foster an inclusive community where technology enthusiasts can share ideas, learn from each other, and grow together."
          />
          
          <ValueCard 
            icon={<GraduationCap className="text-success-500" size={24} />}
            title="Education"
            description="We believe in the power of education and strive to make complex tech concepts accessible and understandable to everyone."
          />
          
          <ValueCard 
            icon={<Rss className="text-warning-500" size={24} />}
            title="Currency"
            description="We stay ahead of the curve, bringing you the latest news and analysis on emerging technologies and digital trends."
          />
          
          <ValueCard 
            icon={<Cpu className="text-error-500" size={24} />}
            title="Innovation"
            description="We embrace innovation in our content delivery, constantly exploring new ways to engage and inform our audience."
          />
        </div>
      </section>

      {/* Team Section */}
      <section className="section py-16">
        <h2 className="text-2xl md:text-3xl font-bold mb-10 text-center">Meet Our Team</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <TeamCard 
            name="Alex Chen"
            role="Founder & Editor-in-Chief"
            image="https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400"
            bio="Tech visionary with 15+ years of experience in the industry. Passionate about the intersection of technology and society."
          />
          
          <TeamCard 
            name="Maya Johnson"
            role="Senior Editor, AI & ML"
            image="https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400"
            bio="PhD in Computer Science with expertise in artificial intelligence and machine learning. Previously worked at leading AI research labs."
          />
          
          <TeamCard 
            name="Raj Patel"
            role="Hardware Review Specialist"
            image="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=400"
            bio="Hardware enthusiast and electrical engineer. Passionate about dismantling gadgets to understand their inner workings."
          />
          
          <TeamCard 
            name="Sophie Taylor"
            role="Cybersecurity Editor"
            image="https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=400"
            bio="Certified ethical hacker with a background in information security. Advocate for privacy and digital rights."
          />
        </div>
      </section>

      {/* Join Us CTA */}
      <section className="section py-16">
        <div className="glass-card p-8 md:p-12 bg-gradient-to-br from-primary-500/10 to-accent-500/10 dark:from-primary-900/30 dark:to-accent-900/30">
          <div className="text-center">
            <h2 className="text-2xl md:text-3xl font-bold mb-6">Join Our Community</h2>
            <p className="text-zinc-700 dark:text-zinc-300 max-w-3xl mx-auto mb-8">
              Be part of our growing community of tech enthusiasts. Stay updated with the latest trends, participate in discussions, and connect with like-minded individuals.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/register" className="btn-primary px-8">
                Sign Up Now
              </Link>
              <Link to="/blog" className="btn-ghost">
                Explore Articles
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

interface ValueCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const ValueCard: React.FC<ValueCardProps> = ({ icon, title, description }) => {
  return (
    <motion.div
      className="glass-card p-6"
      whileHover={{ y: -5 }}
    >
      <div className="flex items-start gap-4">
        <div className="mt-1">
          {icon}
        </div>
        <div>
          <h3 className="text-lg font-semibold mb-2">{title}</h3>
          <p className="text-zinc-600 dark:text-zinc-400 text-sm">
            {description}
          </p>
        </div>
      </div>
    </motion.div>
  );
};

interface TeamCardProps {
  name: string;
  role: string;
  image: string;
  bio: string;
}

const TeamCard: React.FC<TeamCardProps> = ({ name, role, image, bio }) => {
  return (
    <motion.div
      className="glass-card overflow-hidden"
      whileHover={{ y: -5 }}
    >
      <div className="aspect-square overflow-hidden">
        <img 
          src={image} 
          alt={name} 
          className="w-full h-full object-cover transition-transform hover:scale-110"
        />
      </div>
      <div className="p-5">
        <h3 className="font-bold text-lg">{name}</h3>
        <p className="text-sm text-primary-600 dark:text-primary-400 mb-2">{role}</p>
        <p className="text-zinc-600 dark:text-zinc-400 text-sm">
          {bio}
        </p>
      </div>
    </motion.div>
  );
};

export default AboutPage;