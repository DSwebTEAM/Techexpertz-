import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useBlogStore } from '../store/blogStore';
import { PostCard } from '../components/blog/PostCard';
import { CategoryList } from '../components/blog/CategoryList';
import { TagCloud } from '../components/blog/TagCloud';
import { ArrowRight } from 'lucide-react';

const HomePage: React.FC = () => {
  const { posts, categories, tags, fetchPosts, fetchCategories, fetchTags, isLoading } = useBlogStore();
  
  useEffect(() => {
    fetchPosts();
    fetchCategories();
    fetchTags();
  }, [fetchPosts, fetchCategories, fetchTags]);

  const featuredPosts = posts.filter(post => post.featured);
  const recentPosts = posts
    .filter(post => !post.featured)
    .sort((a, b) => new Date(b.publishedAt || '').getTime() - new Date(a.publishedAt || '').getTime())
    .slice(0, 4);

  return (
    <div className="pt-10">
      {/* Hero Section */}
      <section className="py-14 md:py-20 px-4 bg-gradient-to-br from-indigo-100 to-violet-100 dark:from-zinc-900 dark:to-zinc-800">
        <div className="container mx-auto">
          <div className="flex flex-col items-center text-center">
            <motion.h1 
              className="text-3xl md:text-5xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-primary-600 to-accent-600 dark:from-primary-400 dark:to-accent-400"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              Exploring The Future of Technology
            </motion.h1>
            <motion.p 
              className="text-lg md:text-xl text-zinc-700 dark:text-zinc-300 max-w-3xl mb-8"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              Discover cutting-edge innovations, expert reviews, and in-depth analysis on the technology shaping our digital landscape.
            </motion.p>
            <motion.div
              className="flex flex-col sm:flex-row gap-4"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <Link to="/blog" className="btn-primary px-8">
                Explore Articles
              </Link>
              <Link to="/categories" className="btn-ghost">
                Browse Categories
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Featured Posts */}
      <section className="section">
        <div className="flex justify-between items-center mb-10">
          <h2 className="text-2xl md:text-3xl font-bold">Featured Articles</h2>
          <Link to="/blog" className="flex items-center gap-1 text-primary-600 dark:text-primary-400 hover:underline">
            View All <ArrowRight size={16} />
          </Link>
        </div>

        {isLoading ? (
          <div className="text-center py-20">
            <div className="w-12 h-12 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-zinc-500 dark:text-zinc-400">Loading featured articles...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {featuredPosts.length > 0 ? (
              featuredPosts.map(post => (
                <PostCard key={post.id} post={post} featured={true} />
              ))
            ) : (
              <div className="col-span-12 text-center py-10">
                <p className="text-zinc-500 dark:text-zinc-400">No featured articles found.</p>
              </div>
            )}
          </div>
        )}
      </section>

      {/* Recent Posts and Sidebar */}
      <section className="section">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {/* Recent Posts */}
          <div className="lg:col-span-2">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-bold">Recent Articles</h2>
              <Link to="/blog" className="flex items-center gap-1 text-primary-600 dark:text-primary-400 hover:underline">
                More Articles <ArrowRight size={16} />
              </Link>
            </div>
            
            {isLoading ? (
              <div className="text-center py-20">
                <div className="w-12 h-12 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-zinc-500 dark:text-zinc-400">Loading recent articles...</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {recentPosts.map(post => (
                  <PostCard key={post.id} post={post} />
                ))}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <CategoryList 
              categories={categories.slice(0, 4)} 
              className="mb-10" 
            />
            
            <TagCloud 
              tags={tags} 
              className="mb-10" 
            />
            
            {/* Newsletter Subscription */}
            <div className="glass-card p-6">
              <h3 className="text-xl font-bold mb-4">Stay Updated</h3>
              <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-4">
                Subscribe to our newsletter for weekly tech insights delivered straight to your inbox.
              </p>
              <form className="flex flex-col gap-3">
                <input
                  type="email"
                  placeholder="Your email address"
                  className="input py-2"
                  required
                />
                <button type="submit" className="btn-primary">
                  Subscribe
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;