import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useAuthStore } from '../store/authStore';
import { Button } from '../components/ui/Button';
import { Camera, Mail, User, MapPin, Link as LinkIcon, Github, Twitter, Linkedin, Edit2, Check, X } from 'lucide-react';

const ProfilePage: React.FC = () => {
  const { user, updateUser, isLoading } = useAuthStore();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    bio: user?.bio || '',
    location: 'San Francisco, CA',
    website: 'https://techexpertz.com',
    github: 'techguru',
    twitter: 'techguru',
    linkedin: 'techguru',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateUser(formData);
    setIsEditing(false);
  };

  const stats = [
    { label: 'Posts', value: '23' },
    { label: 'Following', value: '148' },
    { label: 'Followers', value: '509' },
    { label: 'Total Views', value: '24.5K' },
  ];

  const recentActivity = [
    {
      type: 'post',
      title: 'The Future of AI: How Machine Learning is Revolutionizing Industries',
      date: '2 days ago',
      views: 1250,
      likes: 78,
    },
    {
      type: 'comment',
      content: 'Great insights on quantum computing applications!',
      post: 'Quantum Computing: The Next Frontier',
      date: '4 days ago',
    },
    {
      type: 'like',
      post: 'Blockchain Beyond Cryptocurrency',
      date: '1 week ago',
    },
  ];

  return (
    <div className="pt-28 pb-20">
      <div className="container mx-auto px-4">
        {/* Profile Header */}
        <div className="glass-card p-8 mb-8 relative overflow-hidden">
          {/* Background Pattern */}
          <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-r from-primary-500/20 to-accent-500/20" />
          
          <div className="relative flex flex-col md:flex-row gap-8 items-center md:items-end">
            {/* Avatar */}
            <div className="relative">
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="w-32 h-32 rounded-full overflow-hidden border-4 border-white dark:border-zinc-800 shadow-xl"
              >
                <img
                  src={user?.avatarUrl || 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150'}
                  alt={user?.name}
                  className="w-full h-full object-cover"
                />
              </motion.div>
              <button className="absolute bottom-0 right-0 p-2 rounded-full bg-white dark:bg-zinc-800 shadow-lg text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 transition-colors">
                <Camera size={18} />
              </button>
            </div>

            {/* Profile Info */}
            <div className="flex-grow text-center md:text-left">
              <div className="flex items-center justify-center md:justify-start gap-4 mb-2">
                <h1 className="text-3xl font-bold">{user?.name}</h1>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsEditing(!isEditing)}
                  icon={isEditing ? <X size={18} /> : <Edit2 size={18} />}
                >
                  {isEditing ? 'Cancel' : 'Edit Profile'}
                </Button>
              </div>
              <p className="text-zinc-600 dark:text-zinc-400 mb-4">{user?.bio}</p>
              
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 text-sm">
                <span className="flex items-center gap-1 text-zinc-600 dark:text-zinc-400">
                  <Mail size={16} />
                  {user?.email}
                </span>
                <span className="flex items-center gap-1 text-zinc-600 dark:text-zinc-400">
                  <MapPin size={16} />
                  San Francisco, CA
                </span>
                <a
                  href="https://techexpertz.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 text-primary-600 dark:text-primary-400 hover:underline"
                >
                  <LinkIcon size={16} />
                  techexpertz.com
                </a>
              </div>
            </div>

            {/* Social Stats */}
            <div className="flex gap-6">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="text-xl font-bold">{stat.value}</div>
                  <div className="text-sm text-zinc-600 dark:text-zinc-400">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Edit Form */}
          {isEditing && (
            <motion.form
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-8 pt-8 border-t border-zinc-200 dark:border-zinc-700"
              onSubmit={handleSubmit}
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium mb-2">Name</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="input w-full"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Location</label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    className="input w-full"
                  />
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium mb-2">Bio</label>
                  <textarea
                    value={formData.bio}
                    onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                    className="input w-full h-24 resize-none"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Website</label>
                  <input
                    type="url"
                    value={formData.website}
                    onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                    className="input w-full"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">GitHub Username</label>
                  <div className="relative">
                    <Github size={18} className="absolute left-3 top-2.5 text-zinc-400" />
                    <input
                      type="text"
                      value={formData.github}
                      onChange={(e) => setFormData({ ...formData, github: e.target.value })}
                      className="input w-full pl-10"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Twitter Username</label>
                  <div className="relative">
                    <Twitter size={18} className="absolute left-3 top-2.5 text-zinc-400" />
                    <input
                      type="text"
                      value={formData.twitter}
                      onChange={(e) => setFormData({ ...formData, twitter: e.target.value })}
                      className="input w-full pl-10"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">LinkedIn Username</label>
                  <div className="relative">
                    <Linkedin size={18} className="absolute left-3 top-2.5 text-zinc-400" />
                    <input
                      type="text"
                      value={formData.linkedin}
                      onChange={(e) => setFormData({ ...formData, linkedin: e.target.value })}
                      className="input w-full pl-10"
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end mt-6 gap-4">
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => setIsEditing(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  isLoading={isLoading}
                  icon={<Check size={18} />}
                >
                  Save Changes
                </Button>
              </div>
            </motion.form>
          )}
        </div>

        {/* Recent Activity */}
        <div className="glass-card p-6">
          <h2 className="text-xl font-bold mb-6">Recent Activity</h2>
          <div className="space-y-6">
            {recentActivity.map((activity, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-start gap-4"
              >
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary-500/20 to-accent-500/20 flex items-center justify-center">
                  {activity.type === 'post' ? (
                    <Edit2 size={20} className="text-primary-600 dark:text-primary-400" />
                  ) : activity.type === 'comment' ? (
                    <MessageCircle size={20} className="text-secondary-600 dark:text-secondary-400" />
                  ) : (
                    <Heart size={20} className="text-accent-600 dark:text-accent-400" />
                  )}
                </div>
                
                <div className="flex-grow">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-medium">
                      {activity.type === 'post'
                        ? 'Published a new post'
                        : activity.type === 'comment'
                        ? 'Commented on'
                        : 'Liked'}
                    </span>
                    <span className="text-xs text-zinc-500 dark:text-zinc-400">
                      {activity.date}
                    </span>
                  </div>
                  
                  <a href="#" className="text-lg font-medium hover:text-primary-600 dark:hover:text-primary-400 transition-colors">
                    {activity.title || activity.post}
                  </a>
                  
                  {activity.type === 'comment' && (
                    <p className="text-sm text-zinc-600 dark:text-zinc-400 mt-1">
                      {activity.content}
                    </p>
                  )}
                  
                  {activity.type === 'post' && (
                    <div className="flex items-center gap-4 mt-2 text-sm text-zinc-500 dark:text-zinc-400">
                      <span className="flex items-center gap-1">
                        <Eye size={14} />
                        {activity.views}
                      </span>
                      <span className="flex items-center gap-1">
                        <Heart size={14} />
                        {activity.likes}
                      </span>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;