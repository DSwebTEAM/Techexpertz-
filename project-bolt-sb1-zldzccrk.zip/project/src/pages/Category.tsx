import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useBlogStore } from '../store/blogStore';
import { PostCard } from '../components/blog/PostCard';
import { CategoryList } from '../components/blog/CategoryList';
import { Category, Post } from '../types';
import { NotFoundPage } from './NotFound';

interface CategoryPageProps {
  showAll?: boolean;
}

const CategoryPage: React.FC<CategoryPageProps> = ({ showAll = false }) => {
  const { slug } = useParams<{ slug: string }>();
  const { posts, categories, fetchPosts, fetchCategories, isLoading } = useBlogStore();
  const [filteredPosts, setFilteredPosts] = useState<Post[]>([]);
  const [currentCategory, setCurrentCategory] = useState<Category | null>(null);

  useEffect(() => {
    fetchPosts();
    fetchCategories();
  }, [fetchPosts, fetchCategories]);

  useEffect(() => {
    if (showAll) {
      // Show all categories page
      return;
    }

    if (slug && categories.length > 0) {
      const category = categories.find(c => c.slug === slug);
      setCurrentCategory(category || null);
      
      if (category) {
        setFilteredPosts(posts.filter(post => post.categoryId === category.id));
      } else {
        setFilteredPosts([]);
      }
    }
  }, [slug, categories, posts, showAll]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex justify-center items-center">
        <div className="w-16 h-16 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!showAll && !currentCategory && !isLoading) {
    return <NotFoundPage />;
  }

  return (
    <div className="pt-10 pb-20">
      {showAll ? (
        // All Categories Page
        <section className="section">
          <h1 className="text-3xl md:text-4xl font-bold mb-12">Browse Categories</h1>
          
          <CategoryList categories={categories} />
        </section>
      ) : (
        // Single Category Page
        <>
          <section className="py-16 px-4 bg-gradient-to-br from-indigo-100 to-violet-100 dark:from-zinc-900 dark:to-zinc-800">
            <div className="container mx-auto">
              <div className="flex flex-col items-center text-center">
                <span className="px-4 py-1 rounded-full text-sm font-medium bg-gradient-to-r from-primary-500 to-accent-500 text-white mb-6">
                  Category
                </span>
                <h1 className="text-3xl md:text-4xl font-bold mb-4">
                  {currentCategory?.name}
                </h1>
                {currentCategory?.description && (
                  <p className="text-lg text-zinc-700 dark:text-zinc-300 max-w-2xl mb-2">
                    {currentCategory.description}
                  </p>
                )}
                <p className="text-sm text-zinc-500 dark:text-zinc-400">
                  {filteredPosts.length} {filteredPosts.length === 1 ? 'article' : 'articles'}
                </p>
              </div>
            </div>
          </section>

          <section className="section">
            {filteredPosts.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredPosts.map(post => (
                  <PostCard key={post.id} post={post} />
                ))}
              </div>
            ) : (
              <div className="glass-card p-10 text-center">
                <p className="text-xl font-medium mb-2">No articles found</p>
                <p className="text-zinc-500 dark:text-zinc-400">
                  There are no articles in this category yet.
                </p>
              </div>
            )}
          </section>
        </>
      )}
    </div>
  );
};

export default CategoryPage;