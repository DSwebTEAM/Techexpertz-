import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { motion } from 'framer-motion';
import { Mail, Lock, User, Eye, EyeOff, Check, X } from 'lucide-react';

const RegisterPage: React.FC = () => {
  const navigate = useNavigate();
  const { register, isLoading, error } = useAuthStore();
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});

  const validateForm = () => {
    const errors: { [key: string]: string } = {};
    
    // Validate email
    if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      errors.email = 'Please enter a valid email address';
    }
    
    // Validate username
    if (username.length < 3) {
      errors.username = 'Username must be at least 3 characters';
    }
    
    // Validate password
    if (password.length < 8) {
      errors.password = 'Password must be at least 8 characters';
    }
    
    // Check password confirmation
    if (password !== confirmPassword) {
      errors.confirmPassword = 'Passwords do not match';
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      await register(email, username, password);
      navigate('/');
    }
  };

  // Password strength indicators
  const hasMinLength = password.length >= 8;
  const hasUppercase = /[A-Z]/.test(password);
  const hasLowercase = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);

  return (
    <div className="min-h-screen pt-28 pb-20 flex items-center justify-center px-4">
      <motion.div 
        className="glass-card p-8 w-full max-w-md"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Create an Account</h1>
          <p className="text-zinc-600 dark:text-zinc-400">
            Join TechExpertz and be part of our tech community
          </p>
        </div>

        {error && (
          <div className="bg-error-50 text-error-700 dark:bg-error-900/30 dark:text-error-400 p-4 rounded-lg mb-6">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-1">
            <label htmlFor="email" className="text-sm font-medium">
              Email
            </label>
            <div className="relative">
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={`input pl-10 w-full ${formErrors.email ? 'border-error-500 dark:border-error-500' : ''}`}
                placeholder="your@email.com"
                required
              />
              <Mail className="absolute left-3 top-2.5 text-zinc-400" size={18} />
            </div>
            {formErrors.email && (
              <p className="text-xs text-error-600 dark:text-error-400 mt-1">{formErrors.email}</p>
            )}
          </div>

          <div className="space-y-1">
            <label htmlFor="username" className="text-sm font-medium">
              Username
            </label>
            <div className="relative">
              <input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className={`input pl-10 w-full ${formErrors.username ? 'border-error-500 dark:border-error-500' : ''}`}
                placeholder="cooluser123"
                required
              />
              <User className="absolute left-3 top-2.5 text-zinc-400" size={18} />
            </div>
            {formErrors.username && (
              <p className="text-xs text-error-600 dark:text-error-400 mt-1">{formErrors.username}</p>
            )}
          </div>

          <div className="space-y-1">
            <label htmlFor="password" className="text-sm font-medium">
              Password
            </label>
            <div className="relative">
              <input
                id="password"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={`input pl-10 pr-10 w-full ${formErrors.password ? 'border-error-500 dark:border-error-500' : ''}`}
                placeholder="••••••••"
                required
              />
              <Lock className="absolute left-3 top-2.5 text-zinc-400" size={18} />
              <button
                type="button"
                className="absolute right-3 top-2.5 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            
            {/* Password strength indicators */}
            {password.length > 0 && (
              <div className="mt-3 space-y-2">
                <div className="grid grid-cols-4 gap-2">
                  <div className={`h-1 rounded-full ${hasMinLength ? 'bg-success-500' : 'bg-zinc-300 dark:bg-zinc-700'}`}></div>
                  <div className={`h-1 rounded-full ${hasUppercase ? 'bg-success-500' : 'bg-zinc-300 dark:bg-zinc-700'}`}></div>
                  <div className={`h-1 rounded-full ${hasLowercase ? 'bg-success-500' : 'bg-zinc-300 dark:bg-zinc-700'}`}></div>
                  <div className={`h-1 rounded-full ${hasNumber ? 'bg-success-500' : 'bg-zinc-300 dark:bg-zinc-700'}`}></div>
                </div>
                
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className={`flex items-center gap-1 ${hasMinLength ? 'text-success-600 dark:text-success-400' : 'text-zinc-500 dark:text-zinc-400'}`}>
                    {hasMinLength ? <Check size={12} /> : <X size={12} />}
                    <span>8+ characters</span>
                  </div>
                  <div className={`flex items-center gap-1 ${hasUppercase ? 'text-success-600 dark:text-success-400' : 'text-zinc-500 dark:text-zinc-400'}`}>
                    {hasUppercase ? <Check size={12} /> : <X size={12} />}
                    <span>Uppercase</span>
                  </div>
                  <div className={`flex items-center gap-1 ${hasLowercase ? 'text-success-600 dark:text-success-400' : 'text-zinc-500 dark:text-zinc-400'}`}>
                    {hasLowercase ? <Check size={12} /> : <X size={12} />}
                    <span>Lowercase</span>
                  </div>
                  <div className={`flex items-center gap-1 ${hasNumber ? 'text-success-600 dark:text-success-400' : 'text-zinc-500 dark:text-zinc-400'}`}>
                    {hasNumber ? <Check size={12} /> : <X size={12} />}
                    <span>Number</span>
                  </div>
                </div>
              </div>
            )}
            
            {formErrors.password && (
              <p className="text-xs text-error-600 dark:text-error-400 mt-1">{formErrors.password}</p>
            )}
          </div>

          <div className="space-y-1">
            <label htmlFor="confirmPassword" className="text-sm font-medium">
              Confirm Password
            </label>
            <div className="relative">
              <input
                id="confirmPassword"
                type={showPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className={`input pl-10 w-full ${formErrors.confirmPassword ? 'border-error-500 dark:border-error-500' : ''}`}
                placeholder="••••••••"
                required
              />
              <Lock className="absolute left-3 top-2.5 text-zinc-400" size={18} />
            </div>
            {formErrors.confirmPassword && (
              <p className="text-xs text-error-600 dark:text-error-400 mt-1">{formErrors.confirmPassword}</p>
            )}
          </div>

          <div className="space-y-1">
            <label className="flex items-start gap-2">
              <input
                type="checkbox"
                className="mt-0.5 form-checkbox rounded border-zinc-300 dark:border-zinc-700 text-primary-600 focus:ring-primary-500"
                required
              />
              <span className="text-sm text-zinc-600 dark:text-zinc-400">
                I agree to the <Link to="/terms" className="text-primary-600 dark:text-primary-400 hover:underline">Terms of Service</Link> and <Link to="/privacy" className="text-primary-600 dark:text-primary-400 hover:underline">Privacy Policy</Link>
              </span>
            </label>
          </div>

          <button
            type="submit"
            className="btn-primary w-full"
            disabled={isLoading}
          >
            {isLoading ? (
              <span className="flex items-center justify-center">
                <span className="w-5 h-5 border-2 border-white/20 border-t-white/80 rounded-full animate-spin mr-2"></span>
                Creating account...
              </span>
            ) : (
              'Create Account'
            )}
          </button>

          <div className="text-center text-sm text-zinc-600 dark:text-zinc-400">
            Already have an account?{' '}
            <Link to="/login" className="text-primary-600 dark:text-primary-400 hover:underline">
              Sign in
            </Link>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

export default RegisterPage;