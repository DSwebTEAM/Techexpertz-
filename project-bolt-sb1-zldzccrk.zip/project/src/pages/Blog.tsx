import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useBlogStore } from '../store/blogStore';
import { PostCard } from '../components/blog/PostCard';
import { CategoryList } from '../components/blog/CategoryList';
import { TagCloud } from '../components/blog/TagCloud';
import { Post, Category, Tag } from '../types';
import { Search, Filter, X } from 'lucide-react';

const BlogPage: React.FC = () => {
  const { posts, categories, tags, fetchPosts, fetchCategories, fetchTags, isLoading } = useBlogStore();
  const [filteredPosts, setFilteredPosts] = useState<Post[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    fetchPosts();
    fetchCategories();
    fetchTags();
  }, [fetchPosts, fetchCategories, fetchTags]);

  useEffect(() => {
    let result = [...posts];
    
    // Filter by search term
    if (searchTerm) {
      result = result.filter(
        post => 
          post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
          post.content.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    // Filter by category
    if (selectedCategory) {
      result = result.filter(post => post.category.id === selectedCategory);
    }
    
    // Filter by tags
    if (selectedTags.length > 0) {
      result = result.filter(post => 
        post.tags.some(tag => selectedTags.includes(tag.id))
      );
    }
    
    setFilteredPosts(result);
  }, [posts, searchTerm, selectedCategory, selectedTags]);

  const handleTagToggle = (tagId: string) => {
    setSelectedTags(prev => 
      prev.includes(tagId)
        ? prev.filter(id => id !== tagId)
        : [...prev, tagId]
    );
  };

  const clearFilters = () => {
    setSearchTerm('');
    setSelectedCategory(null);
    setSelectedTags([]);
  };

  return (
    <div className="pt-10 pb-20">
      <section className="py-16 px-4 bg-gradient-to-br from-indigo-100 to-violet-100 dark:from-zinc-900 dark:to-zinc-800">
        <div className="container mx-auto">
          <div className="flex flex-col items-center text-center">
            <motion.h1 
              className="text-3xl md:text-4xl font-bold mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Explore Our Articles
            </motion.h1>
            <motion.p 
              className="text-lg text-zinc-700 dark:text-zinc-300 max-w-2xl mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Discover the latest news, reviews, and insights on cutting-edge technology.
            </motion.p>
            
            <motion.div 
              className="w-full max-w-2xl"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search articles..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="input py-3 pl-12 pr-12 w-full"
                />
                <Search className="absolute left-4 top-3.5 text-zinc-400" size={20} />
                {searchTerm && (
                  <button 
                    onClick={() => setSearchTerm('')}
                    className="absolute right-4 top-3.5 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200"
                  >
                    <X size={20} />
                  </button>
                )}
              </div>

              <div className="flex justify-between mt-4">
                <button 
                  onClick={() => setShowFilters(!showFilters)}
                  className="flex items-center gap-2 text-sm text-zinc-600 dark:text-zinc-400 hover:text-primary-600 dark:hover:text-primary-400"
                >
                  <Filter size={16} />
                  {showFilters ? 'Hide Filters' : 'Show Filters'}
                </button>
                
                {(searchTerm || selectedCategory || selectedTags.length > 0) && (
                  <button 
                    onClick={clearFilters}
                    className="text-sm text-zinc-600 dark:text-zinc-400 hover:text-primary-600 dark:hover:text-primary-400"
                  >
                    Clear all filters
                  </button>
                )}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar with filters */}
          {showFilters && (
            <motion.div 
              className="lg:col-span-1"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
            >
              <div className="sticky top-24">
                <div className="glass-card p-6 mb-6">
                  <h2 className="text-xl font-bold mb-4">Categories</h2>
                  <div className="space-y-2">
                    {categories.map((category: Category) => (
                      <button
                        key={category.id}
                        onClick={() => setSelectedCategory(
                          selectedCategory === category.id ? null : category.id
                        )}
                        className={`block w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${
                          selectedCategory === category.id
                            ? 'bg-primary-100 text-primary-700 dark:bg-primary-900/30 dark:text-primary-400'
                            : 'hover:bg-zinc-100 dark:hover:bg-zinc-800'
                        }`}
                      >
                        {category.name}
                        {category.postCount && (
                          <span className="ml-2 text-xs text-zinc-500 dark:text-zinc-400">
                            ({category.postCount})
                          </span>
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="glass-card p-6">
                  <h2 className="text-xl font-bold mb-4">Tags</h2>
                  <div className="flex flex-wrap gap-2">
                    {tags.map((tag: Tag) => (
                      <button
                        key={tag.id}
                        onClick={() => handleTagToggle(tag.id)}
                        className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                          selectedTags.includes(tag.id)
                            ? 'bg-primary-100 text-primary-700 dark:bg-primary-900/30 dark:text-primary-400'
                            : 'bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700'
                        }`}
                      >
                        {tag.name}
                        {tag.postCount && (
                          <span className="ml-1 opacity-70">
                            ({tag.postCount})
                          </span>
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* Blog posts */}
          <div className={`${showFilters ? 'lg:col-span-3' : 'lg:col-span-4'}`}>
            {isLoading ? (
              <div className="text-center py-20">
                <div className="w-12 h-12 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-zinc-500 dark:text-zinc-400">Loading articles...</p>
              </div>
            ) : (
              <>
                {/* Results summary */}
                {(searchTerm || selectedCategory || selectedTags.length > 0) && (
                  <div className="mb-6 pb-6 border-b border-zinc-200 dark:border-zinc-800">
                    <p className="text-sm text-zinc-500 dark:text-zinc-400">
                      Showing {filteredPosts.length} {filteredPosts.length === 1 ? 'result' : 'results'}
                      {searchTerm && (
                        <span> for <span className="font-medium text-zinc-700 dark:text-zinc-300">"{searchTerm}"</span></span>
                      )}
                      {selectedCategory && (
                        <span> in <span className="font-medium text-zinc-700 dark:text-zinc-300">
                          {categories.find(c => c.id === selectedCategory)?.name || ''}
                        </span></span>
                      )}
                      {selectedTags.length > 0 && (
                        <span> with tags <span className="font-medium text-zinc-700 dark:text-zinc-300">
                          {selectedTags.map(id => 
                            tags.find(t => t.id === id)?.name
                          ).join(', ')}
                        </span></span>
                      )}
                    </p>
                  </div>
                )}

                {filteredPosts.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredPosts.map(post => (
                      <PostCard key={post.id} post={post} />
                    ))}
                  </div>
                ) : (
                  <div className="glass-card p-10 text-center">
                    <p className="text-xl font-medium mb-2">No articles found</p>
                    <p className="text-zinc-500 dark:text-zinc-400 mb-6">
                      Try adjusting your search or filter criteria
                    </p>
                    <button 
                      onClick={clearFilters}
                      className="btn-primary"
                    >
                      Clear all filters
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default BlogPage;