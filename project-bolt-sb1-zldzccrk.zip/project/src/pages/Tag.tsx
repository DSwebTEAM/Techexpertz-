import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useBlogStore } from '../store/blogStore';
import { PostCard } from '../components/blog/PostCard';
import { Tag, Post } from '../types';
import { NotFoundPage } from './NotFound';

const TagPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const { posts, tags, fetchPosts, fetchTags, isLoading } = useBlogStore();
  const [filteredPosts, setFilteredPosts] = useState<Post[]>([]);
  const [currentTag, setCurrentTag] = useState<Tag | null>(null);

  useEffect(() => {
    fetchPosts();
    fetchTags();
  }, [fetchPosts, fetchTags]);

  useEffect(() => {
    if (slug && tags.length > 0) {
      const tag = tags.find(t => t.slug === slug);
      setCurrentTag(tag || null);
      
      if (tag) {
        setFilteredPosts(
          posts.filter(post => post.tags.some(t => t.id === tag.id))
        );
      } else {
        setFilteredPosts([]);
      }
    }
  }, [slug, tags, posts]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex justify-center items-center">
        <div className="w-16 h-16 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!currentTag && !isLoading) {
    return <NotFoundPage />;
  }

  return (
    <div className="pt-10 pb-20">
      <section className="py-16 px-4 bg-gradient-to-br from-indigo-100 to-violet-100 dark:from-zinc-900 dark:to-zinc-800">
        <div className="container mx-auto">
          <div className="flex flex-col items-center text-center">
            <span className="px-4 py-1 rounded-full text-sm font-medium bg-gradient-to-r from-primary-500 to-accent-500 text-white mb-6">
              Tag
            </span>
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              #{currentTag?.name}
            </h1>
            <p className="text-sm text-zinc-500 dark:text-zinc-400">
              {filteredPosts.length} {filteredPosts.length === 1 ? 'article' : 'articles'}
            </p>
          </div>
        </div>
      </section>

      <section className="section">
        {filteredPosts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPosts.map(post => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        ) : (
          <div className="glass-card p-10 text-center">
            <p className="text-xl font-medium mb-2">No articles found</p>
            <p className="text-zinc-500 dark:text-zinc-400">
              There are no articles with this tag yet.
            </p>
          </div>
        )}
      </section>
    </div>
  );
};

export default TagPage;