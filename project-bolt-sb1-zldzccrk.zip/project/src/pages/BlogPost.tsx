import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { useBlogStore } from '../store/blogStore';
import { Post, Tag } from '../types';
import { NotFoundPage } from './NotFound';
import { TagCloud } from '../components/blog/TagCloud';
import { ArrowLeft, Clock, Calendar, Eye, Heart, Share2, Bookmark, ChevronLeft, ChevronRight } from 'lucide-react';
import { format } from 'date-fns';

const BlogPostPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const { fetchPostBySlug, posts, likePost, isLoading } = useBlogStore();
  const [post, setPost] = useState<Post | undefined>(undefined);
  const [relatedPosts, setRelatedPosts] = useState<Post[]>([]);
  const [liked, setLiked] = useState(false);

  useEffect(() => {
    const loadPost = async () => {
      if (slug) {
        const fetchedPost = await fetchPostBySlug(slug);
        setPost(fetchedPost);

        // Find related posts based on category and tags
        if (fetchedPost) {
          const related = posts
            .filter(p => 
              p.id !== fetchedPost.id && 
              (p.categoryId === fetchedPost.categoryId || 
               p.tags.some(t => fetchedPost.tags.map(ft => ft.id).includes(t.id)))
            )
            .slice(0, 3);
          setRelatedPosts(related);
        }
      }
    };

    loadPost();
  }, [slug, fetchPostBySlug, posts]);

  const handleLike = () => {
    if (post && !liked) {
      likePost(post.id);
      setLiked(true);
      // Update local post state to immediately reflect the like
      setPost(prev => prev ? { ...prev, likes: prev.likes + 1 } : undefined);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex justify-center items-center">
        <div className="w-16 h-16 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!post && !isLoading) {
    return <NotFoundPage />;
  }

  if (!post) return null;

  const formattedDate = post.publishedAt 
    ? format(new Date(post.publishedAt), 'MMMM d, yyyy')
    : '';

  return (
    <div className="pt-10 pb-20">
      {/* Hero Section */}
      <section className="relative h-[50vh] min-h-[400px] overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-zinc-900/70 to-zinc-900/90 z-10"></div>
        <img 
          src={post.coverImage || 'https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'} 
          alt={post.title} 
          className="absolute w-full h-full object-cover"
        />
        
        <div className="container mx-auto px-4 relative z-20 h-full flex flex-col justify-end pb-12">
          <Link 
            to="/blog" 
            className="flex items-center gap-2 text-white/70 hover:text-white mb-6 w-fit"
          >
            <ArrowLeft size={16} />
            <span>Back to Blog</span>
          </Link>
          
          <Link
            to={`/blog/category/${post.category.slug}`}
            className="mb-4 w-fit"
          >
            <span className="px-3 py-1 rounded-full text-xs font-medium bg-primary-500/30 text-primary-100 backdrop-blur-sm">
              {post.category.name}
            </span>
          </Link>
          
          <motion.h1 
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6 max-w-4xl"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {post.title}
          </motion.h1>
          
          <motion.div
            className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-white/80"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <div className="flex items-center gap-2">
              <img 
                src={post.author.avatarUrl || 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150'} 
                alt={post.author.name}
                className="w-8 h-8 rounded-full object-cover"
              />
              <span>{post.author.name}</span>
            </div>
            
            <div className="flex items-center gap-1">
              <Calendar size={14} />
              <span>{formattedDate}</span>
            </div>
            
            <div className="flex items-center gap-1">
              <Clock size={14} />
              <span>{post.readingTime} min read</span>
            </div>
            
            <div className="flex items-center gap-1">
              <Eye size={14} />
              <span>{post.views} views</span>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="section">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Main Content */}
          <div className="lg:col-span-8">
            <div className="glass-card p-8 mb-8">
              <article className="prose prose-lg dark:prose-invert max-w-none prose-img:rounded-xl prose-headings:font-display">
                <ReactMarkdown remarkPlugins={[remarkGfm]}>
                  {post.content}
                </ReactMarkdown>
              </article>

              <div className="border-t border-zinc-200 dark:border-zinc-800 mt-8 pt-6">
                <div className="flex flex-wrap gap-4">
                  {post.tags.map((tag: Tag) => (
                    <Link 
                      key={tag.id}
                      to={`/blog/tag/${tag.slug}`}
                      className="px-3 py-1 rounded-full text-xs font-medium bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors"
                    >
                      #{tag.name}
                    </Link>
                  ))}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="glass-card p-6 mb-8">
              <div className="flex flex-wrap justify-between items-center gap-4">
                <div className="flex items-center gap-6">
                  <button
                    onClick={handleLike}
                    className={`flex items-center gap-2 ${
                      liked ? 'text-error-500 dark:text-error-400' : 'text-zinc-600 dark:text-zinc-400 hover:text-error-500 dark:hover:text-error-400'
                    } transition-colors`}
                    disabled={liked}
                  >
                    <Heart size={20} fill={liked ? 'currentColor' : 'none'} />
                    <span>{post.likes} likes</span>
                  </button>
                  
                  <button className="flex items-center gap-2 text-zinc-600 dark:text-zinc-400 hover:text-zinc-800 dark:hover:text-zinc-200 transition-colors">
                    <Share2 size={20} />
                    <span>Share</span>
                  </button>
                  
                  <button className="flex items-center gap-2 text-zinc-600 dark:text-zinc-400 hover:text-zinc-800 dark:hover:text-zinc-200 transition-colors">
                    <Bookmark size={20} />
                    <span>Save</span>
                  </button>
                </div>
                
                <Link 
                  to={`/blog/category/${post.category.slug}`}
                  className="flex items-center gap-2 text-primary-600 dark:text-primary-400 hover:underline"
                >
                  More in {post.category.name}
                  <ChevronRight size={16} />
                </Link>
              </div>
            </div>

            {/* Author Bio */}
            <div className="glass-card p-6 mb-8">
              <div className="flex flex-col md:flex-row gap-6 items-center md:items-start">
                <img 
                  src={post.author.avatarUrl || 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150'} 
                  alt={post.author.name}
                  className="w-20 h-20 rounded-full object-cover"
                />
                <div>
                  <h3 className="text-xl font-bold mb-2">{post.author.name}</h3>
                  <p className="text-zinc-600 dark:text-zinc-400 mb-4">
                    {post.author.bio || 'Tech enthusiast and writer covering the latest innovations and digital trends.'}
                  </p>
                  <div className="flex gap-3">
                    <Link 
                      to={`/author/${post.author.username}`}
                      className="text-sm text-primary-600 dark:text-primary-400 hover:underline"
                    >
                      View Profile
                    </Link>
                    <span className="text-zinc-300 dark:text-zinc-600">|</span>
                    <Link 
                      to={`/author/${post.author.username}/posts`}
                      className="text-sm text-primary-600 dark:text-primary-400 hover:underline"
                    >
                      All Articles
                    </Link>
                  </div>
                </div>
              </div>
            </div>

            {/* Related Posts */}
            {relatedPosts.length > 0 && (
              <div>
                <h2 className="text-2xl font-bold mb-6">Related Articles</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {relatedPosts.map(relatedPost => (
                    <Link 
                      key={relatedPost.id}
                      to={`/blog/${relatedPost.slug}`}
                      className="glass-card overflow-hidden group"
                    >
                      <div className="relative h-40 overflow-hidden">
                        <img 
                          src={relatedPost.coverImage || 'https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'} 
                          alt={relatedPost.title}
                          className="w-full h-full object-cover transition-transform group-hover:scale-105"
                        />
                      </div>
                      <div className="p-4">
                        <h3 className="font-bold text-lg mb-2 line-clamp-2 group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors">
                          {relatedPost.title}
                        </h3>
                        <p className="text-sm text-zinc-500 dark:text-zinc-400">
                          {relatedPost.readingTime} min read
                        </p>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-4">
            <div className="sticky top-24">
              <TagCloud 
                tags={post.tags.length > 5 ? post.tags : [...post.tags, ...useBlogStore.getState().tags.slice(0, 10-post.tags.length)]} 
                className="glass-card p-6 mb-8" 
              />
              
              {/* Newsletter */}
              <div className="glass-card p-6 mb-8">
                <h3 className="text-xl font-bold mb-4">Subscribe to Newsletter</h3>
                <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-4">
                  Get the latest articles and industry updates delivered to your inbox.
                </p>
                <form className="flex flex-col gap-3">
                  <input
                    type="email"
                    placeholder="Your email address"
                    className="input py-2"
                    required
                  />
                  <button type="submit" className="btn-primary">
                    Subscribe
                  </button>
                </form>
              </div>
              
              {/* Post Navigation */}
              <div className="glass-card p-6">
                <div className="flex flex-col gap-4">
                  {posts.findIndex(p => p.id === post.id) > 0 && (
                    <Link
                      to={`/blog/${posts[posts.findIndex(p => p.id === post.id) - 1].slug}`}
                      className="flex items-center gap-2 text-zinc-700 dark:text-zinc-300 hover:text-primary-600 dark:hover:text-primary-400 transition-colors"
                    >
                      <ChevronLeft size={18} />
                      <div>
                        <div className="text-xs text-zinc-500 dark:text-zinc-400">Previous Article</div>
                        <div className="font-medium line-clamp-1">{posts[posts.findIndex(p => p.id === post.id) - 1].title}</div>
                      </div>
                    </Link>
                  )}
                  
                  {posts.findIndex(p => p.id === post.id) < posts.length - 1 && (
                    <Link
                      to={`/blog/${posts[posts.findIndex(p => p.id === post.id) + 1].slug}`}
                      className="flex items-center gap-2 text-zinc-700 dark:text-zinc-300 hover:text-primary-600 dark:hover:text-primary-400 transition-colors"
                    >
                      <div className="text-right">
                        <div className="text-xs text-zinc-500 dark:text-zinc-400">Next Article</div>
                        <div className="font-medium line-clamp-1">{posts[posts.findIndex(p => p.id === post.id) + 1].title}</div>
                      </div>
                      <ChevronRight size={18} />
                    </Link>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default BlogPostPage;